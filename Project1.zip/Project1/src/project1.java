/** 
 * 
 * @author Darius Jenkins
 * SE403
 * Project 1
 * 
 */


import java.io.File;
import java.io.FileNotFoundException;
import java.util.LinkedList;
import java.util.Scanner;


public class project1 {
	
	String numbers1;
	File newOne;
	LinkedList<Integer> numbers;
	
	
	public project1() {
		numbers1="";
		newOne = new File("numbers");
		numbers = new LinkedList<Integer>();
	}

	public void readData() {
		
	try {
	Scanner newText = new Scanner(newOne); 
	
	while (newText.hasNextLine()) 
	{
		numbers1 = newText.nextLine();
		numbers.add(Integer.parseInt(numbers1));
	}
	
	newText.close();
	
	for (int i = 0; i<numbers.size(); i++) {
		System.out.println(numbers.get(i));
		}
	}
	
	catch(FileNotFoundException exc) {
		exc.printStackTrace();
		System.out.println("Your file is not found");
		}
	}


public double mean () {
	int total = 0;
	double mean = 0;
	
	for(int i =0;i<numbers.size(); i++) {
		total += numbers.get(i);
	}
	
	mean = (double)total/numbers.size();
	return mean;
}


public double standardDeviation() {
	double sd=0;
	double var = 0;
	double meanValue = mean();
			
			for (int i = 0;i<numbers.size(); i++) {
				var+= Math.pow(numbers.get(i) - meanValue, 2);
			}
			
			var = var/(numbers.size()-1);
			
			sd=Math.sqrt(var);
			return sd;
			
}

}


