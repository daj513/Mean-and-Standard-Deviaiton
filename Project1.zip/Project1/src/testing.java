/** 
 * 
 * @author Darius Jenkins
 * SE403
 * Project 1
 * 
 */

public class testing {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		project1 proj = new project1();
		project2 proj2 = new project2();
		
		proj.readData();
		
		
		
		System.out.println("Mean value of the Integers in the linked list is: " + proj.mean());
		System.out.println("The standard deviation of Integers in the list is: " + proj.standardDeviation());
		
		
		proj2.readDataMethod();
		System.out.println("Mean value of the Integers in the linked list is: " + proj2.meanMethod());
		System.out.println("The standard deviation of Integers in the list is: " + proj2.standardDeviationMethod());
}
}