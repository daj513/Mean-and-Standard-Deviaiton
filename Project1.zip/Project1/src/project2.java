/** 
 * 
 * @author Darius Jenkins
 * SE403
 * Project 1
 * 
 */


import java.io.File;
import java.io.FileNotFoundException;
import java.util.LinkedList;
import java.util.Scanner;

public class project2 {

	String numbers2;
	File newTwo;
	LinkedList<Double> hours;
	
	public project2() {
		numbers2="";
		newTwo = new File("hours");
		hours = new LinkedList<Double>();
	}
	
	public void readDataMethod() {
		
		try {

		Scanner newText = new Scanner(newTwo); 
		
		while (newText.hasNextLine()) 
		{
			numbers2 = newText.nextLine();
			hours.add(Double.parseDouble(numbers2));
		}
		
		newText.close();
		
		for (int i = 0; i<hours.size(); i++) {
			System.out.println(hours.get(i));
			}
		}
		
		catch(FileNotFoundException exc) {
			exc.printStackTrace();
			System.out.println("Your file is not found");
			}
		}
	
	public double meanMethod () {
		int total = 0;
		double mean = 0;
		
		for(int i =0;i<hours.size(); i++) {
			total += hours.get(i);
		}
		
		mean = (double)total/hours.size();
		return mean;
	}


	public double standardDeviationMethod() {
		double sd=0;
		double var = 0;
		double meanValue = meanMethod();
				
				for (int i = 0;i<hours.size(); i++) {
					var+= Math.pow(hours.get(i) - meanValue, 2);
				}
				
				var = var/(hours.size()-1);
				
				sd=Math.sqrt(var);
				return sd;
				
	}
}
